#!/bin/bash

BASE_DIR="$(cd "$(dirname "$0")" && pwd)"
"$BASE_DIR/scripts/verify.sh"
STATUS=$?
printf '\nPress Return to close this window. '
IFS= read -r _
exit "$STATUS"

