# Troubleshooting

## Installer says the CPU supports AVX

This workaround is not applicable. An AVX-capable CPU should not fault on the instruction addressed here. Diagnose the newest Safari/WebKit crash report instead.

## Installer says Safari is not 26.6.1

The machine-code signatures are tied to the tested Safari release. Do not force installation unless you have independently disassembled and validated the target JavaScriptCore binary.

## `revpatch` does not contain `jsc`

Rebuild OpenCore with an OCLP version that supports the JavaScriptCore patch. This installer deliberately does not rewrite `config.plist` or NVRAM.

## RestrictEvents 1.1.7 is still loaded

The Mac did not boot through the EFI that received the replacement, or that EFI contains another RestrictEvents copy/configuration. Restart with Option held, explicitly choose the intended OpenCore device, and verify again.

## RestrictEvents 1.1.8 is loaded but Safari still crashes

Collect the newest report from both locations:

```sh
find ~/Library/Logs/DiagnosticReports /Library/Logs/DiagnosticReports \
  -type f -mmin -15 2>/dev/null | grep -Ei 'Safari|WebKit|JavaScriptCore|GPU'
```

If the exception is still `SIGILL` in `ctiMasmProbeTrampoline`, the Safari binary probably did not match the known signatures. If the exception or crashing process differs, diagnose that new evidence: WebKit GPU process, media decode, graphics driver, and OCLP root patches are separate paths.

## OCLP reports a dirty system volume

This project does not alter or repair the sealed system volume. Resolve root-patch prerequisites with OCLP's documented procedure. Replacing a kext in an EFI cannot clean the system volume.

## Restore

Run `Restore Original RestrictEvents.command`, or copy the saved RestrictEvents kext from `~/Desktop/Safari-AVX-Fix-Backups/<timestamp>-<disk>/EFI/OC/Kexts/` back to the same EFI. If needed, restore the entire backed-up `EFI` directory.

