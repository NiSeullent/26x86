# Safari 26 pre-AVX fix

An experimental, source-available RestrictEvents patch that stops Safari 26.6.1 WebContent from executing AVX instructions on Intel Macs whose CPUs do not support AVX.

> [!IMPORTANT]
> This is a narrowly scoped community workaround, not an official Acidanthera, Dortania, OpenCore Legacy Patcher, or Apple release. It was tested on one MacPro5,1 configuration. Keep a known-good bootable OpenCore USB and test there before touching an internal EFI.

> [!CAUTION]
> **Use at your own risk.** Modifying an EFI or loading an experimental kernel extension can prevent a Mac from booting and may cause data loss, instability, or security problems. You are responsible for reviewing the source, selecting the correct disk, keeping verified backups, and recovering the machine if anything goes wrong. No warranty or support guarantee is provided.

## The short version

Safari 26.6.1 on the tested pre-AVX MacPro5,1 crashed as soon as video playback entered JavaScriptCore's `ctiMasmProbeTrampoline`. The crash was `EXC_BAD_INSTRUCTION (SIGILL)` at a `vmovaps` instruction. The regular `revpatch=jsc` fix correctly hid AVX capability, but Safari 26.6.1 still used 32 unconditional AVX-encoded XMM save/restore instructions in that trampoline.

This fork keeps the existing JavaScriptCore capability patch and replaces those two complete, version-specific instruction blocks with equivalent legacy SSE `movaps` encodings. The patched RestrictEvents 1.1.8 was loaded from a USB OpenCore EFI and the previously crashing YouTube video played normally, with stable WebContent and GPU processes and no new crash report.

## Who should use it

Use this release only when all of the following are true:

- the Mac has an Intel CPU **without AVX**;
- Safari is **26.6.1**;
- Safari/WebContent crashes with `EXC_BAD_INSTRUCTION`, `SIGILL`, or `Illegal instruction` in JavaScriptCore, especially `ctiMasmProbeTrampoline`;
- OpenCore already loads Lilu and RestrictEvents;
- `revpatch` already contains `jsc`.

The verified machine was:

| Component | Verified configuration |
|---|---|
| Mac | MacPro5,1 |
| CPU | 2 × Intel Xeon E5620 (Westmere, no AVX) |
| GPU | NVIDIA Quadro K5000 |
| macOS | 15.7.9 (24G830) |
| Safari | 26.6.1 |
| OCLP | 2.5.0 nightly, commit `af9b49a` |
| Lilu | 1.7.1 |
| RestrictEvents | 1.1.8 from this project |

Do not install this merely because Safari video fails. GPU process, media decoding, graphics-driver, and root-patch failures can look similar but need different fixes. See [Troubleshooting](docs/TROUBLESHOOTING.md).

## Easy installation

1. Download `Safari26-PreAVX-Fix-1.1.8.zip` from [Releases](https://github.com/kilinccagatay/Safari26-PreAVX-Fix/releases).
2. Extract it and keep your known-good OpenCore USB connected.
3. Right-click **Install Safari AVX Fix.command** and choose **Open**.
4. Read the detected CPU, Safari version, EFI list, and selected target carefully.
5. Type the requested disk identifier, then type `INSTALL` to confirm.
6. Restart while holding Option and boot the OpenCore entry from that USB.
7. Run **Verify Safari AVX Fix.command**, then test the page that previously crashed.

The installer:

- refuses AVX-capable CPUs and Safari versions other than 26.6.1;
- checks the bundled binary checksum;
- requires an existing OpenCore EFI with enabled RestrictEvents and `revpatch=jsc`;
- makes a full EFI backup on the Desktop;
- replaces only `EFI/OC/Kexts/RestrictEvents.kext`;
- does not edit `config.plist`, NVRAM, root patches, or system files;
- never changes the startup disk and never reboots automatically.

To undo the replacement, run **Restore Original RestrictEvents.command** and select the backup created by the installer. Full manual instructions are in [Installation and rollback](docs/INSTALL.md).

## Verify the result

After booting through the modified EFI, run:

```sh
kmutil showloaded | grep -i RestrictEvents
```

The loaded version must be `1.1.8`. Version 1.1.7 means the Mac booted through another EFI or still has the unmodified kext.

Then reproduce the original crash and check for a fresh WebKit crash:

```sh
find ~/Library/Logs/DiagnosticReports /Library/Logs/DiagnosticReports \
  -type f -mmin -10 2>/dev/null | grep -Ei 'Safari|WebKit|JavaScriptCore|GPU'
```

## Build it yourself

This repository retains the upstream RestrictEvents history and BSD 3-Clause license. The fix is implemented in:

- `RestrictEvents/JavaScriptCore.hpp`
- `RestrictEvents/RestrictEvents.cpp`
- `RestrictEvents.xcodeproj/project.pbxproj`

A typical release build needs Xcode, MacKernelSDK, and the Lilu bootstrap files:

```sh
git clone https://github.com/kilinccagatay/Safari26-PreAVX-Fix.git
cd Safari26-PreAVX-Fix
git clone https://github.com/acidanthera/MacKernelSDK.git
source <(curl -Lfs https://raw.githubusercontent.com/acidanthera/Lilu/master/Lilu/Scripts/bootstrap.sh)
xcodebuild -jobs 1 -configuration Release
```

Review remote scripts before executing them. Exact reproducibility notes, artifact hashes, and a local-build alternative are in [Building from source](docs/BUILD.md).

## Technical findings

The faulting bytes began with `c5 f8 29`, decoded as an AVX `vmovaps` store. Safari's trampoline contained 16 such stores and 16 corresponding loads. The existing `jsc` path patched the JavaScriptCore AVX feature state but did not rewrite this unconditional trampoline.

The new patch searches only for the two complete Safari 26.6.1 byte sequences. For XMM0–XMM7 it replaces the VEX prefix with a one-byte NOP plus legacy `0f 28/29`; for XMM8–XMM15 it uses `44 0f 28/29`, where `REX.R` selects the high register. Every replacement is the same length as the original, so following addresses remain unchanged.

The capability check and trampoline sequences may be encountered on the same 4 KiB vnode page. The patch therefore applies all matching transformations before returning. See [Technical analysis](docs/TECHNICAL.md) for the crash evidence and validation details.

## Scope and limitations

- Byte signatures are Safari-version-specific. A Safari update may no longer match; in that case the patch should fail closed, but the original crash can return.
- The included kext is unsigned community code. It is intended for an existing OpenCore/Lilu environment, not installation into macOS itself.
- The installer cannot prove which EFI firmware will choose on the next boot. Select the intended OpenCore device manually at startup.
- This project does not repair a dirty sealed system volume or install OCLP root patches.
- Only the configuration above has received an end-to-end runtime test so far.

## Credits and license

Based on [Acidanthera RestrictEvents](https://github.com/acidanthera/RestrictEvents), with the JavaScriptCore pre-AVX work based on upstream commit `b70aaa4`. RestrictEvents and this fork are distributed under the BSD 3-Clause license in [LICENSE.txt](LICENSE.txt). See [NOTICE.md](NOTICE.md) for attribution and project status.
