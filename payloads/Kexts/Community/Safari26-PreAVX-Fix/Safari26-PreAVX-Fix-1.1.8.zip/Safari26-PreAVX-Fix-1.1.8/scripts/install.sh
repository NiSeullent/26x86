#!/bin/bash

set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PROJECT_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"
# shellcheck source=lib.sh
source "$SCRIPT_DIR/lib.sh"

PAYLOAD="$PROJECT_DIR/Payload/RestrictEvents.kext"
TARGET_DISK=""
trap cleanup_mount EXIT

heading "Safari 26 pre-AVX fix installer"
printf 'This tool changes only RestrictEvents.kext on an EFI that you select.\n'
printf 'It does not edit config.plist, NVRAM, root patches, or macOS system files.\n'
printf 'Use at your own risk. Keep a known-good bootable EFI and current backups.\n'

verify_payload "$PAYLOAD"

if [ "${1:-}" = "--self-test" ]; then
  printf 'Installer payload self-test passed.\n'
  exit 0
fi

[ "$(/usr/bin/uname -m)" = "x86_64" ] || die "This fix is only for Intel Macs."
CPU_BRAND="$(/usr/sbin/sysctl -n machdep.cpu.brand_string 2>/dev/null || true)"
CPU_FEATURES="$(/usr/sbin/sysctl -n machdep.cpu.features 2>/dev/null || true) $(/usr/sbin/sysctl -n machdep.cpu.leaf7_features 2>/dev/null || true)"
printf 'CPU: %s\n' "${CPU_BRAND:-unknown Intel CPU}"
if printf '%s\n' "$CPU_FEATURES" | /usr/bin/grep -Eq '(^|[[:space:]])AVX([[:space:]]|$)'; then
  die "This CPU reports AVX support. The Safari illegal-instruction workaround is not applicable."
fi
printf 'CPU AVX feature: not present (compatible with this workaround)\n'

SAFARI_PLIST="/Applications/Safari.app/Contents/Info.plist"
[ -f "$SAFARI_PLIST" ] || die "Safari was not found in /Applications."
SAFARI_VERSION="$(/usr/bin/defaults read "$SAFARI_PLIST" CFBundleShortVersionString 2>/dev/null || true)"
printf 'Safari: %s\n' "${SAFARI_VERSION:-unknown}"
[ "$SAFARI_VERSION" = "$EXPECTED_SAFARI_VERSION" ] || \
  die "This payload is validated only for Safari $EXPECTED_SAFARI_VERSION. No EFI changes were made."

show_efi_partitions
printf '\nType the exact EFI identifier to modify (example: disk4s1), or press Return to cancel: '
IFS= read -r TARGET_DISK
[ -n "$TARGET_DISK" ] || die "Cancelled."
printf '%s\n' "$TARGET_DISK" | /usr/bin/grep -Eq '^disk[0-9]+s[0-9]+$' || die "Invalid disk identifier."
is_known_efi "$TARGET_DISK" || die "$TARGET_DISK is not one of the detected EFI partitions."

heading "Selected target"
/usr/sbin/diskutil info "$TARGET_DISK" | /usr/bin/grep -E 'Device Identifier|Volume Name|Protocol|Disk Size|Media Name|Removable Media|Device Location' || true
printf '\nType INSTALL in uppercase to continue: '
IFS= read -r CONFIRM
[ "$CONFIRM" = "INSTALL" ] || die "Cancelled."

heading "Administrator authorization"
/usr/bin/sudo -v || die "Administrator authorization failed."
mount_efi "$TARGET_DISK"

CONFIG="$MOUNT_POINT/EFI/OC/config.plist"
TARGET_KEXT="$MOUNT_POINT/EFI/OC/Kexts/RestrictEvents.kext"
[ -d "$TARGET_KEXT" ] || die "Existing RestrictEvents.kext not found at $TARGET_KEXT."
check_opencore_config "$CONFIG"

BACKUP_ROOT="$HOME/Desktop/Safari-AVX-Fix-Backups"
BACKUP_DIR="$BACKUP_ROOT/$(/bin/date '+%Y%m%d-%H%M%S')-$TARGET_DISK"
/bin/mkdir -p "$BACKUP_DIR"
heading "Creating full EFI backup"
/usr/bin/ditto "$MOUNT_POINT/EFI" "$BACKUP_DIR/EFI"
printf '%s\n' "$TARGET_DISK" > "$BACKUP_DIR/source-disk.txt"
[ -d "$BACKUP_DIR/EFI/OC/Kexts/RestrictEvents.kext" ] || die "Backup validation failed; target was not changed."
printf 'Backup: %s\n' "$BACKUP_DIR"

heading "Installing RestrictEvents 1.1.8"
STAGED_KEXT="$MOUNT_POINT/EFI/OC/Kexts/RestrictEvents.kext.safari-avx-new"
/usr/bin/sudo /bin/rm -rf "$STAGED_KEXT"
/usr/bin/sudo /usr/bin/ditto "$PAYLOAD" "$STAGED_KEXT"
STAGED_SHA="$(/usr/bin/shasum -a 256 "$STAGED_KEXT/Contents/MacOS/RestrictEvents" | /usr/bin/awk '{print $1}')"
[ "$STAGED_SHA" = "$EXPECTED_EXECUTABLE_SHA256" ] || die "Staged copy failed checksum validation; existing kext was not replaced."
/usr/bin/sudo /bin/rm -rf "$TARGET_KEXT"
/usr/bin/sudo /bin/mv "$STAGED_KEXT" "$TARGET_KEXT"

INSTALLED_SHA="$(/usr/bin/shasum -a 256 "$TARGET_KEXT/Contents/MacOS/RestrictEvents" | /usr/bin/awk '{print $1}')"
[ "$INSTALLED_SHA" = "$EXPECTED_EXECUTABLE_SHA256" ] || die "Installed kext failed checksum validation. Restore the backup before booting."
/bin/sync

heading "Installation complete"
printf 'Installed RestrictEvents: 1.1.8\n'
printf 'EFI: %s (%s)\n' "$TARGET_DISK" "$MOUNT_POINT"
printf 'Backup: %s\n\n' "$BACKUP_DIR"
printf 'Next: restart while holding Option, explicitly boot OpenCore from this device,\n'
printf 'then run Verify Safari AVX Fix.command. This script did not change your startup disk.\n'
