#!/bin/bash

set -u

EXPECTED_EXECUTABLE_SHA256="5862fd1c5415fa94b6d0165e70200eae80ef9e3b1dd4d89220c669507d79f7ef"
EXPECTED_SAFARI_VERSION="26.6.1"
NVRAM_GUID="4D1FDA02-38C7-4A6A-9CC6-4BCCA8B30102"
MOUNT_POINT=""
MOUNTED_BY_SCRIPT=0

die() {
  printf '\nERROR: %s\n' "$*" >&2
  exit 1
}

heading() {
  printf '\n== %s ==\n' "$*"
}

cleanup_mount() {
  if [ "${MOUNTED_BY_SCRIPT:-0}" -eq 1 ] && [ -n "${TARGET_DISK:-}" ]; then
    /usr/sbin/diskutil unmount "$TARGET_DISK" >/dev/null 2>&1 || true
  fi
}

list_efi_partitions() {
  /usr/sbin/diskutil list | /usr/bin/awk '$0 ~ / EFI / && $NF ~ /^disk[0-9]+s[0-9]+$/ {print $NF}'
}

is_known_efi() {
  local candidate="$1"
  list_efi_partitions | /usr/bin/grep -Fxq "$candidate"
}

show_efi_partitions() {
  local disk
  heading "Detected EFI partitions"
  for disk in $(list_efi_partitions); do
    printf '\n[%s]\n' "$disk"
    /usr/sbin/diskutil info "$disk" | /usr/bin/grep -E 'Device Identifier|Device Node|Volume Name|Mounted|Mount Point|Protocol|Disk Size|Media Name|Removable Media|Device Location' || true
  done
}

mount_efi() {
  local disk="$1"
  local info
  info="$(/usr/sbin/diskutil info "$disk")" || die "Cannot inspect $disk."
  MOUNT_POINT="$(printf '%s\n' "$info" | /usr/bin/awk -F: '/Mount Point/ {sub(/^[[:space:]]+/, "", $2); print $2; exit}')"

  if [ -z "$MOUNT_POINT" ] || [ "$MOUNT_POINT" = "Not mounted" ]; then
    /usr/bin/sudo /usr/sbin/diskutil mount "$disk" >/dev/null || die "Could not mount $disk."
    MOUNTED_BY_SCRIPT=1
    info="$(/usr/sbin/diskutil info "$disk")"
    MOUNT_POINT="$(printf '%s\n' "$info" | /usr/bin/awk -F: '/Mount Point/ {sub(/^[[:space:]]+/, "", $2); print $2; exit}')"
  fi

  [ -d "$MOUNT_POINT/EFI" ] || die "$disk is mounted, but it has no EFI directory."
}

check_opencore_config() {
  local config="$1"
  local index=0
  local bundle enabled revpatch found=0

  [ -f "$config" ] || die "OpenCore config not found at $config."
  /usr/bin/plutil -lint "$config" >/dev/null || die "config.plist is not valid."

  while bundle="$(/usr/libexec/PlistBuddy -c "Print :Kernel:Add:$index:BundlePath" "$config" 2>/dev/null)"; do
    if [ "$bundle" = "RestrictEvents.kext" ]; then
      found=1
      enabled="$(/usr/libexec/PlistBuddy -c "Print :Kernel:Add:$index:Enabled" "$config" 2>/dev/null || true)"
      [ "$enabled" = "true" ] || die "RestrictEvents.kext exists in config.plist but is not enabled."
      break
    fi
    index=$((index + 1))
  done

  [ "$found" -eq 1 ] || die "No RestrictEvents.kext entry was found under Kernel -> Add."

  revpatch="$(/usr/libexec/PlistBuddy -c "Print :NVRAM:Add:$NVRAM_GUID:revpatch" "$config" 2>/dev/null || true)"
  printf 'Configured revpatch: %s\n' "${revpatch:-<missing>}"
  printf ',%s,' "$revpatch" | /usr/bin/grep -Eiq ',[[:space:]]*jsc[[:space:]]*(,|$)' || \
    die "revpatch does not contain jsc. Rebuild OpenCore with a compatible OCLP release; this installer will not edit config.plist."
}

verify_payload() {
  local payload="$1"
  local actual
  [ -f "$payload/Contents/MacOS/RestrictEvents" ] || die "Bundled RestrictEvents executable is missing."
  [ -f "$payload/Contents/Info.plist" ] || die "Bundled RestrictEvents Info.plist is missing."
  actual="$(/usr/bin/shasum -a 256 "$payload/Contents/MacOS/RestrictEvents" | /usr/bin/awk '{print $1}')"
  [ "$actual" = "$EXPECTED_EXECUTABLE_SHA256" ] || die "Payload checksum mismatch. Expected $EXPECTED_EXECUTABLE_SHA256, got $actual."
  printf 'Payload SHA-256: %s (verified)\n' "$actual"
}
