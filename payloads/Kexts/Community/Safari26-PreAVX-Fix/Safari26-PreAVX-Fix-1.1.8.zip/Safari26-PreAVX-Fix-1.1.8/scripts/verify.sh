#!/bin/bash

set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
# shellcheck source=lib.sh
source "$SCRIPT_DIR/lib.sh"

heading "Safari 26 pre-AVX fix verification"
printf 'CPU: %s\n' "$(/usr/sbin/sysctl -n machdep.cpu.brand_string 2>/dev/null || echo unknown)"
printf 'macOS: %s (%s)\n' "$(/usr/bin/sw_vers -productVersion)" "$(/usr/bin/sw_vers -buildVersion)"
SAFARI_PLIST="/Applications/Safari.app/Contents/Info.plist"
printf 'Safari: %s\n' "$(/usr/bin/defaults read "$SAFARI_PLIST" CFBundleShortVersionString 2>/dev/null || echo unknown)"

heading "Loaded kernel extensions"
LOADED="$(/usr/bin/kmutil showloaded 2>/dev/null | /usr/bin/grep -i 'as.vit9696.RestrictEvents' || true)"
if [ -z "$LOADED" ]; then
  printf 'RestrictEvents is not shown as loaded.\n'
  exit 1
fi
printf '%s\n' "$LOADED"
if printf '%s\n' "$LOADED" | /usr/bin/grep -Eq '1\.1\.8'; then
  printf '\nPASS: RestrictEvents 1.1.8 is loaded.\n'
else
  printf '\nFAIL: RestrictEvents is loaded, but not version 1.1.8.\n'
  printf 'The Mac probably booted through a different EFI.\n'
  exit 1
fi

heading "Recent Safari/WebKit diagnostic reports (last 15 minutes)"
REPORTS="$(/usr/bin/find "$HOME/Library/Logs/DiagnosticReports" /Library/Logs/DiagnosticReports -type f -mmin -15 2>/dev/null | /usr/bin/grep -Ei 'Safari|WebKit|JavaScriptCore|GPU' || true)"
if [ -n "$REPORTS" ]; then
  printf '%s\n' "$REPORTS"
  printf '\nInspect any report created after your playback test.\n'
else
  printf 'None found.\n'
fi

printf '\nNow reproduce the page that previously crashed. Successful loading alone does not prove playback.\n'

