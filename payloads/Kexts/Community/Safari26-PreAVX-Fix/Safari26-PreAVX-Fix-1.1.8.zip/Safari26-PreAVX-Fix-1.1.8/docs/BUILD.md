# Building from source

## Provenance

The source patch is based on the upstream RestrictEvents `javascriptcore` branch at commit `b70aaa4`. The project version is changed to 1.1.8. The upstream commit history and BSD 3-Clause license are retained.

## Standard Xcode build

Requirements:

- an Intel or Apple silicon Mac capable of running a current full Xcode installation;
- Xcode command-line tools selected with `xcode-select`;
- Git and network access for MacKernelSDK and Lilu bootstrap dependencies.

```sh
git clone https://github.com/kilinccagatay/Safari26-PreAVX-Fix.git
cd Safari26-PreAVX-Fix
git clone https://github.com/acidanthera/MacKernelSDK.git
source <(curl -Lfs https://raw.githubusercontent.com/acidanthera/Lilu/master/Lilu/Scripts/bootstrap.sh)
xcodebuild -jobs 1 -configuration Release
```

The Xcode project follows Acidanthera's normal kext build layout. Inspect `build/Release` and the generated archives after the command completes.

For a dependency-pinned or audited build, download the bootstrap script separately, inspect it, and replace the `master` references with reviewed commits. This fork intentionally does not run an unpinned remote bootstrap automatically in GitHub Actions.

## Verify a result

```sh
file path/to/RestrictEvents.kext/Contents/MacOS/RestrictEvents
nm path/to/RestrictEvents.kext/Contents/MacOS/RestrictEvents | \
  grep -E '(_kmod_info|_start|_stop)'
plutil -p path/to/RestrictEvents.kext/Contents/Info.plist
shasum -a 256 path/to/RestrictEvents.kext/Contents/MacOS/RestrictEvents
```

Expect an x86_64 Mach-O kext bundle, the kmod entry points, bundle version 1.1.8, and the `REVJSCProbePatch` marker.

The binary included in this repository and its first release was built and tested before publication. Its executable checksum is:

```text
5862fd1c5415fa94b6d0165e70200eae80ef9e3b1dd4d89220c669507d79f7ef
```

Compiler/toolchain changes can produce a different whole-file hash even when the source is equivalent. Review the source diff and inspect the resulting binary rather than treating this hash as a reproducible-build guarantee.
