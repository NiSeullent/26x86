# Installation and rollback

## Before you begin

This procedure changes an OpenCore EFI. A mistake or selection of the wrong EFI can make that device unbootable. Keep a separate known-good boot option available.

Use this software at your own risk. It is experimental, unsigned community code provided without warranty. Back up important data as well as the complete EFI before proceeding.

Confirm that the failure is an illegal-instruction crash, not merely a blank player or GPU-process reset. The installer is intentionally limited to Intel CPUs without AVX and Safari 26.6.1.

## Recommended: test on a USB EFI

1. Build and install OpenCore to a USB with OCLP as usual.
2. Boot through that USB once and confirm OpenCore works.
3. Download and extract the release archive.
4. Right-click `Install Safari AVX Fix.command`, choose **Open**, and enter the administrator password when macOS asks.
5. The script lists EFI partitions. Type the identifier belonging to the USB, such as `disk4s1`.
6. Check the printed disk description. Type `INSTALL` only if it is the intended target.
7. The script stores a complete copy under `~/Desktop/Safari-AVX-Fix-Backups/` and replaces only the RestrictEvents kext.
8. Restart, hold Option, and choose the OpenCore entry on the USB.
9. Run `Verify Safari AVX Fix.command`. Confirm RestrictEvents 1.1.8 is loaded.
10. Play the same video or page that previously caused the crash.

The script does not edit OpenCore's configuration. Your existing `config.plist` must already have an enabled `Kernel -> Add` entry for `RestrictEvents.kext`, and `NVRAM -> Add -> 4D1FDA02-38C7-4A6A-9CC6-4BCCA8B30102 -> revpatch` must contain `jsc`.

## Manual installation

1. Mount the intended EFI partition.
2. Copy the entire `EFI` directory somewhere safe.
3. Verify the release executable checksum:

   ```sh
   shasum -a 256 Payload/RestrictEvents.kext/Contents/MacOS/RestrictEvents
   ```

   Expected: `5862fd1c5415fa94b6d0165e70200eae80ef9e3b1dd4d89220c669507d79f7ef`.

4. Replace `EFI/OC/Kexts/RestrictEvents.kext` with `Payload/RestrictEvents.kext`.
5. Do not add a second RestrictEvents entry. Its existing executable path should remain `Contents/MacOS/RestrictEvents` and its plist path `Contents/Info.plist`.
6. Boot explicitly through the modified EFI and verify version 1.1.8 with `kmutil showloaded`.

## Rollback

Run `Restore Original RestrictEvents.command`. It asks for one of the timestamped backup directories and the target EFI partition, then restores only the saved RestrictEvents kext.

For a complete manual rollback, mount the same partition and restore the full saved `EFI` directory. The complete copy is located inside the selected timestamped backup directory.

## Why there is no `.pkg`

A macOS installer package is a poor safety boundary for this task: the destination is a user-selected FAT EFI partition rather than the active macOS volume, and firmware may boot a different EFI afterward. The interactive `.command` installer can display the physical device, require exact confirmation, make a readable backup, and avoid pretending it can choose the next boot device. The release is not notarized; Gatekeeper may require right-clicking the command and choosing **Open**.
