# Technical analysis

## Symptom and original failure

On the tested MacPro5,1, Safari 26.6.1 terminated its WebContent process within roughly two seconds of starting video. The crash report identified:

```text
Exception Type:  EXC_BAD_INSTRUCTION (SIGILL)
Termination Signal: Illegal instruction: 4
JavaScriptCore: ctiMasmProbeTrampoline + 164
Instruction bytes: c5 f8 29 ...
```

The `c5 f8 29` prefix decodes as a VEX-encoded `vmovaps` store. Intel Xeon E5620 is Westmere and does not implement AVX, so executing that instruction necessarily raises `#UD`, surfaced by macOS as `SIGILL`.

This evidence distinguishes the observed failure from a WebKit GPU-process crash, hardware-video decode error, NVIDIA driver failure, or missing graphics root patch. Those can still exist on other machines and should be diagnosed independently.

## Why the previous `jsc` fix was insufficient

The OCLP 2.5.0 nightly configuration was verified to load Lilu 1.7.1 and RestrictEvents 1.1.7, with `revpatch=sbvmm,jsc`. Upstream RestrictEvents commit `b70aaa4` patches JavaScriptCore's AVX capability state on pre-AVX CPUs.

Safari 26.6.1 nevertheless contains a probe trampoline that saves XMM0–XMM15 with 16 unconditional AVX-encoded stores and restores them with 16 unconditional AVX-encoded loads. Hiding AVX capability cannot protect a path whose generated machine code does not branch on that capability.

## Patch design

This fork adds two all-bytes-exact signatures:

- the complete 16-instruction XMM save block;
- the complete 16-instruction XMM restore block.

It replaces only those complete blocks:

| Registers | Original | Replacement | Size strategy |
|---|---|---|
| XMM0–XMM7 | `c5 f8 28/29 ...` | `90 0f 28/29 ...` | one NOP preserves length |
| XMM8–XMM15 | `c5 78 28/29 ...` | `44 0f 28/29 ...` | `REX.R` selects high register |

Both AVX `vmovaps` and legacy SSE `movaps` preserve the same 128-bit XMM values for these operands. Replacements are byte-for-byte equal in length, so no offsets or control-flow targets move.

The existing AVX capability signature and the new trampoline blocks can appear while the vnode callback is processing the same 4 KiB page. Returning immediately after the first successful match skipped later transformations. The callback now attempts both probe-block replacements and the existing capability patch before returning.

Version 1.1.8 logs the following on a complete probe match:

```text
patched JavaScriptCore JIT probe AVX save/restore in cryptex
```

## Runtime validation

The patched kext was installed only on a USB OpenCore EFI. After explicitly booting through that device:

```text
as.vit9696.RestrictEvents (1.1.8)
as.vit9696.Lilu (1.7.1)
```

At 2026-08-28 19:54:12 local time the original YouTube reproduction URL was opened, followed by another YouTube video. Playback continued for more than two minutes. The relevant WebContent processes and WebKit GPU process remained stable, and no new Safari/WebKit `SIGILL` crash report appeared. Before the patch, the same path failed in about two seconds.

This is strong end-to-end evidence for the specific tested build. It is not evidence of compatibility with every Safari or macOS release.

## Artifact identity

| Artifact | SHA-256 |
|---|---|
| `RestrictEvents.kext/Contents/MacOS/RestrictEvents` | `5862fd1c5415fa94b6d0165e70200eae80ef9e3b1dd4d89220c669507d79f7ef` |
| `RestrictEvents.kext/Contents/Info.plist` | `5ae4e9f1053acc415bf4e56f9c32b6d4e53b2fbaf7b4485a4ee956e8b84ac028` |

The executable is an x86_64 `MH_KEXT_BUNDLE` and exports the required kmod metadata, including `_kmod_info`, `_start`, and `_stop`.

## Safety behavior

The signatures intentionally match the observed Safari 26.6.1 code exactly. A changed Safari build should not be partially or heuristically rewritten. If no match is found, RestrictEvents logs a patch failure and JavaScriptCore remains unchanged; the original Safari crash may then return.

