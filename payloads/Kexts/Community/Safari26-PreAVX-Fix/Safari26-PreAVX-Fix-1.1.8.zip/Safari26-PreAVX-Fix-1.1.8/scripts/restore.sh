#!/bin/bash

set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
# shellcheck source=lib.sh
source "$SCRIPT_DIR/lib.sh"

TARGET_DISK=""
trap cleanup_mount EXIT
BACKUP_ROOT="$HOME/Desktop/Safari-AVX-Fix-Backups"

heading "Restore original RestrictEvents"
[ -d "$BACKUP_ROOT" ] || die "No backup directory exists at $BACKUP_ROOT."
printf 'Available backups:\n'
/usr/bin/find "$BACKUP_ROOT" -mindepth 1 -maxdepth 1 -type d -print | /usr/bin/sort
printf '\nPaste the complete backup path, or press Return to cancel: '
IFS= read -r BACKUP_DIR
[ -n "$BACKUP_DIR" ] || die "Cancelled."
BACKUP_ROOT_REAL="$(cd "$BACKUP_ROOT" && pwd -P)"
[ -d "$BACKUP_DIR" ] || die "The selected backup directory does not exist."
BACKUP_DIR="$(cd "$BACKUP_DIR" && pwd -P)"
case "$BACKUP_DIR" in
  "$BACKUP_ROOT_REAL"/*) ;;
  *) die "The selected directory resolves outside $BACKUP_ROOT_REAL." ;;
esac
BACKUP_KEXT="$BACKUP_DIR/EFI/OC/Kexts/RestrictEvents.kext"
[ -d "$BACKUP_KEXT" ] || die "The selected backup has no RestrictEvents.kext."

show_efi_partitions
printf '\nType the exact EFI identifier to restore (example: disk4s1): '
IFS= read -r TARGET_DISK
printf '%s\n' "$TARGET_DISK" | /usr/bin/grep -Eq '^disk[0-9]+s[0-9]+$' || die "Invalid disk identifier."
is_known_efi "$TARGET_DISK" || die "$TARGET_DISK is not one of the detected EFI partitions."

heading "Selected target"
/usr/sbin/diskutil info "$TARGET_DISK" | /usr/bin/grep -E 'Device Identifier|Volume Name|Protocol|Disk Size|Media Name|Removable Media|Device Location' || true
printf '\nType RESTORE in uppercase to continue: '
IFS= read -r CONFIRM
[ "$CONFIRM" = "RESTORE" ] || die "Cancelled."

/usr/bin/sudo -v || die "Administrator authorization failed."
mount_efi "$TARGET_DISK"
TARGET_KEXT="$MOUNT_POINT/EFI/OC/Kexts/RestrictEvents.kext"
[ -d "$(/usr/bin/dirname "$TARGET_KEXT")" ] || die "OpenCore Kexts directory not found."

STAGED_KEXT="$MOUNT_POINT/EFI/OC/Kexts/RestrictEvents.kext.restore-new"
/usr/bin/sudo /bin/rm -rf "$STAGED_KEXT"
/usr/bin/sudo /usr/bin/ditto "$BACKUP_KEXT" "$STAGED_KEXT"
[ -f "$STAGED_KEXT/Contents/MacOS/RestrictEvents" ] || die "Staged restore is incomplete; existing kext was not replaced."
/usr/bin/sudo /bin/rm -rf "$TARGET_KEXT"
/usr/bin/sudo /bin/mv "$STAGED_KEXT" "$TARGET_KEXT"
/bin/sync

heading "Restore complete"
printf 'Restored RestrictEvents.kext from:\n%s\n' "$BACKUP_DIR"
printf 'Restart and explicitly boot OpenCore from %s.\n' "$TARGET_DISK"
